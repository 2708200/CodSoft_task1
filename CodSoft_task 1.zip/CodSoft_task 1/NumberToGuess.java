package com.test;

import java.util.Random;
import java.util.Scanner;

public class NumberToGuess {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        boolean playAgain = true;
        int totalScore = 0;

        while (playAgain) {
            // Random number from 1 to 100
            int numberToGuess = random.nextInt(100) + 1;
            int numberOfAttempts = 0;
            boolean guessedCorrectly = false;
            int attempts = 5;

            System.out.println("Guess the number between 1 and 100:");

            while (numberOfAttempts < attempts && !guessedCorrectly) {
                System.out.print("Enter your guess: ");
                int userGuess = sc.nextInt();
                numberOfAttempts++;

                if (userGuess == numberToGuess) {
                    guessedCorrectly = true;
                    System.out.println("Congratulations! Your guess is correct. It took you " + numberOfAttempts + " attempts.");
                    // Score is based on the number of attempts left
                    totalScore += (attempts - numberOfAttempts + 1);
                } else if (userGuess < numberToGuess) {
                    System.out.println("Too low! Try again.");
                } else {
                    System.out.println("Too high! Try again.");
                }
            }

            if (!guessedCorrectly) {
                System.out.println("Sorry, you've used all your attempts. The number was " + numberToGuess);
            }

            System.out.print("Do you want to play again? (yes/no): ");
            String userResponse = sc.next();
            playAgain = userResponse.equalsIgnoreCase("yes");
        }

        System.out.println("Your total score is: " + totalScore);
        System.out.println("Thank you for playing the game!");
        sc.close();
    }
}
